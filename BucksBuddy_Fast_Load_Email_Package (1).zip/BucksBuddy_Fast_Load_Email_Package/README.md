# BucksBuddy fast-loading email package

This package contains the production HTML, a local preview, and all optimized WebP assets.

## Performance

- Total image payload: **105,808 bytes (about 103 KB)**
- Approximately **90% smaller** than the earlier image set
- Assets are sized close to 2× their visible email dimensions for sharp rendering on high-density screens
- Every image has an explicit width, height, and alt attribute in the HTML

## Use

1. Upload the complete `assets/webp/` directory to your web server or CDN.
2. Open `email-production.html` and replace:
   `https://YOUR-DOMAIN.com/bucksbuddy-email/assets/webp/`
   with the public URL of your uploaded WebP directory.
3. Replace `[Name]` and `YOUR_EMAIL_HERE` with your sending-platform variables or final values.
4. Send a test to Gmail, Outlook, Apple Mail, and one mobile device before starting the campaign.

Use `email-local-preview.html` to review the design locally without changing asset URLs.

## Server recommendation

Serve WebP files with `Content-Type: image/webp`. If you version asset filenames when replacing them, enable a long cache policy such as `Cache-Control: public, max-age=31536000, immutable`.

